package sample;

public class StartScreenController {
}

package sample;

import javafx.fxml.FXML;

public class AddingTeamsController {

    @FXML
    void initialize() {

    }


}

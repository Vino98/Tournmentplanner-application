package tournament;

public enum TournamentType {
    Group, Knockout, GroupAndKnockout;
}

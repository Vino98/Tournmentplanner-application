package tournament.pool;

public enum KnockoutChoice {

    Placement, Knockout, PlacementAndKnockout;
}

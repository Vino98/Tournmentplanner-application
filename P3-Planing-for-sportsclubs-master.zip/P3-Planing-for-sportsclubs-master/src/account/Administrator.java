package account;

public class Administrator extends Account.User {

    private boolean logIn() {
        return true;
    }
}

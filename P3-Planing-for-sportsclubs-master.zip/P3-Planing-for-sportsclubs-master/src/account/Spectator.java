package Account;

public class Spectator extends User {

}
